import SwiftUI

@main
struct OUDS_Onboarding_TutorialApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

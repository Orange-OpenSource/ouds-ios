import SwiftUI

@main
struct OUDS_Discovery_TutorialApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

import OUDSSwiftUI
import SwiftUI

@main
struct OUDS_Lime_TutorialApp: App {
    var body: some Scene {
        WindowGroup {
            OUDSThemeableView(theme: OrangeTheme()) {
                ContentView()
            }
        }
    }
}
